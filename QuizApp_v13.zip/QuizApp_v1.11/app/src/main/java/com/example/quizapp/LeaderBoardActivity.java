package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

/*import com.example.quizapp.Class.User;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.mongodb.stitch.android.core.Stitch;
import com.mongodb.stitch.android.core.StitchAppClient;
import com.mongodb.stitch.android.core.auth.StitchUser;
import com.mongodb.stitch.android.services.mongodb.remote.RemoteMongoClient;
import com.mongodb.stitch.android.services.mongodb.remote.RemoteMongoCollection;
import com.mongodb.stitch.core.auth.providers.anonymous.AnonymousCredential;
import com.mongodb.stitch.core.services.mongodb.remote.RemoteUpdateOptions;
import com.mongodb.stitch.core.services.mongodb.remote.RemoteUpdateResult; */

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


//import org.bson.Document;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class LeaderBoardActivity extends AppCompatActivity {
    private String userName;
    Button result;
    Button postBtn;
    private EditText userInput;
    DatabaseReference databaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        databaseUser= FirebaseDatabase.getInstance().getReference("user");
        userInput = findViewById(R.id.userInput);
        postBtn = findViewById(R.id.postBtn);
        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            // The name added by the user is stored in the 'username' variable.
            public void onClick(View view) {
                userName = userInput.getText().toString(); // User input is converted into a string.
                showToast(userName);
                addUser();
            }

        });
        // When return button is clicked, it takes user back to the "select year" menu to restart the trivia game.
        result = findViewById(R.id.result);
        result.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                openResultActivity();
            }
        });


    }
    private void addUser(){
        String username=userName;
        int userScore=getIntent().getIntExtra("leaderScore",0);
        if(!TextUtils.isEmpty(username)){
            String id =databaseUser.push().getKey();
            User user = new User(id,username,userScore);
            databaseUser.child(id).setValue(user);
            Toast.makeText(this, "User & Score Added", Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this, "You should enter a Username", Toast.LENGTH_LONG).show();
        }
    }
    // Return button returns back to Start Activity
    public void openResultActivity(){
        Intent intent = new Intent(this, StartActivity.class);
        startActivity(intent);
    }
    // User can insert username
    private void showToast(String text) {
        Toast.makeText(LeaderBoardActivity.this, text, Toast.LENGTH_SHORT).show();
    }
    // Post button allows user to uplaod their username to the wesbite's leader board
    public void openLeaderBoardActivity(View view){
        Intent intent = new Intent(getApplicationContext(), LeaderBoardActivity.class);
        startActivity(intent); //Post
    }

}

