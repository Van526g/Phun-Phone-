package com.example.quizapp;

public class User {

    public String name;
    public int score;


    public void SetName(String userName) {
        this.name = userName;
    }

    public void SetScore(int highScore) {
        this.score = highScore;
    }
};
