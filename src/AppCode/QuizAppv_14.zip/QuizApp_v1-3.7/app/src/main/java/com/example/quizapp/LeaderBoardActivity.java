package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.text.Html;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
//import androidx.appcompat.widget.Toolbar;

//import com.example.quizapp.Class.User;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
//import com.google.android.material.floatingactionbutton.FloatingActionButton;
//import com.google.android.material.snackbar.Snackbar;
import com.mongodb.stitch.android.core.Stitch;
import com.mongodb.stitch.android.core.StitchAppClient;
import com.mongodb.stitch.android.core.auth.StitchUser;
import com.mongodb.stitch.android.services.mongodb.remote.RemoteMongoClient;
import com.mongodb.stitch.android.services.mongodb.remote.RemoteMongoCollection;
import com.mongodb.stitch.core.auth.providers.anonymous.AnonymousCredential;
import com.mongodb.stitch.core.services.mongodb.remote.RemoteInsertOneResult;
import com.mongodb.stitch.core.services.mongodb.remote.RemoteUpdateOptions;
import com.mongodb.stitch.core.services.mongodb.remote.RemoteUpdateResult;
import com.mongodb.stitch.core.internal.common.BsonUtils;

import com.mongodb.stitch.core.services.mongodb.remote.sync.ChangeEventListener;
import com.mongodb.stitch.core.services.mongodb.remote.sync.DefaultSyncConflictResolvers;
import com.mongodb.stitch.core.services.mongodb.remote.sync.ErrorListener;
import com.mongodb.stitch.core.services.mongodb.remote.sync.internal.ChangeEvents;

import com.mongodb.stitch.android.services.mongodb.local.LocalMongoDbService;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;


import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class LeaderBoardActivity extends AppCompatActivity {
    private String username;
    Button result;
    Button postBtn;
    private EditText userInput;
    private TextView wlink;

    public StitchAppClient stitchClient;
    public RemoteMongoClient mongoClient;
    public RemoteMongoCollection itemsCollection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        userInput = (EditText)findViewById(R.id.userInput);
        postBtn = (Button)findViewById(R.id.postBtn);
        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            // The name added by the user is stored in the 'username' variable.
            public void onClick(View view) {
                username = userInput.getText().toString(); // User input is converted into a string.
                int score = getIntent().getIntExtra("highScore",0);
                User newPlayer = new User();

                newPlayer.SetName(username);
                newPlayer.SetScore(score);
                pushToMongo(newPlayer);

                showToast(username);
            }

        });
        // When return button is clicked, it takes user back to the "select year" menu to restart the trivia game.
        result = findViewById(R.id.result);
        result.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                openResultActivity();
            }
        });

        // Link to Leaderboard Website - linkify class is used
        String wlink = "Click to access <a href=\"https://oconnoran17.github.io/TerrierTrivia/index.html\">leaderboard website</a>";
        TextView link = (TextView) findViewById(R.id.link);
        link.setText(Html.fromHtml(wlink));
        link.setMovementMethod(LinkMovementMethod.getInstance());

    }
    // Return button returns back to Start Activity
    public void openResultActivity(){
        Intent intent = new Intent(this, StartActivity.class);
        startActivity(intent);
    }
    // User can insert username
    private void showToast(String text) {
        Toast.makeText(LeaderBoardActivity.this, text, Toast.LENGTH_SHORT).show();
    }
    // Post button allows user to uplaod their username to the wesbite's leader board
    public void openLeaderBoardActivity(View view){
        Intent intent = new Intent(getApplicationContext(), LeaderBoardActivity.class);
        startActivity(intent); //Post
    }

    public void pushToMongo(User username) {

        stitchClient = Stitch.getDefaultAppClient();
        mongoClient = stitchClient.getServiceClient(RemoteMongoClient.factory, "mongodb-atlas");
        RemoteMongoCollection playersCollection = mongoClient.getDatabase("LeaderBoard").getCollection("players");

        Document newItem = new Document()
                .append("name", username.name)
                .append("score", username.score)
                ;


        final Task <RemoteInsertOneResult> insertTask = playersCollection.insertOne(newItem);
        insertTask.addOnCompleteListener(new OnCompleteListener <RemoteInsertOneResult> (){
            @Override
            public void onComplete(@NonNull Task <RemoteInsertOneResult> task) {
                if (task.isSuccessful()) {
                    Log.d("app", String.format("successfully inserted item with id %s",
                            task.getResult().getInsertedId()));
                } else {
                    Log.e("app", "failed to insert document with: ", task.getException());
                }
            }
        });

//        final StitchAppClient client =
//                Stitch.initializeDefaultAppClient("terriertrivia-vykbt");

//        final RemoteMongoClient mongoClient =
//                client.getServiceClient(RemoteMongoClient.factory, "mongodb-atlas");
//
//        final RemoteMongoCollection<Document> coll =
//                mongoClient.getDatabase("LeaderBoard").getCollection("players");

//        client.getAuth().loginWithCredential(new AnonymousCredential()).continueWithTask(
//                new Continuation<StitchUser, Task<RemoteUpdateResult>>() {
//
//                    @Override
//                    public Task<RemoteUpdateResult> then(@NonNull Task<StitchUser> task) throws Exception {
//                        if (!task.isSuccessful()) {
//                            Log.e("STITCH", "Login failed!");
//                            throw task.getException();
//                        }
//
//                        final Document updateDoc = new Document("name", username.name);
//                        updateDoc.put("score", username.score);
//                        return coll.updateOne(null, updateDoc, new RemoteUpdateOptions().upsert(true));
//                    }
//                }
//        ).continueWithTask(new Continuation<RemoteUpdateResult, Task<List<Document>>>() {
//            @Override
//            public Task<List<Document>> then(@NonNull Task<RemoteUpdateResult> task) throws Exception {
//                if (!task.isSuccessful()) {
//                    Log.e("STITCH", "Update failed!");
//                    throw task.getException();
//                }
//                List<Document> docs = new ArrayList<>();
//                return coll
//                        .find(new Document("owner_id", client.getAuth().getUser().getId()))
//                        .limit(100)
//                        .into(docs);
//            }
//        }).addOnCompleteListener(new OnCompleteListener<List<Document>>() {
//            @Override
//            public void onComplete(@NonNull Task<List<Document>> task) {
//                if (task.isSuccessful()) {
//                    Log.d("STITCH", "Found docs: " + task.getResult().toString());
//                    return;
//                }
//                Log.e("STITCH", "Error: " + task.getException().toString());
//                task.getException().printStackTrace();
//            }
//        });


//   //public void savePlayer(String username, int highscore) {
//    //   User newPlayer = new User();
//
//       newPlayer.SetName(username);
//       newPlayer.SetScore(highscore);

        //pushToMongo(newPlayer);
//   }


        //@Override
        //protected void onCreate(Bundle savedInstanceState) {
        //    super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_leaderboard);

        /*   <ImageView
        android:id="@+id/logo"
        android:layout_width="168dp"
        android:layout_height="156dp"
        android:layout_marginTop="10dp"
        android:background="@mipmap/ic_launcher" />  */


    }


}

